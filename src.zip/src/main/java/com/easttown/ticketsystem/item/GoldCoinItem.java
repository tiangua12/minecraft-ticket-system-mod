
// GoldCoinItem.java
package com.easttown.ticketsystem.item;

import net.minecraft.world.item.Item;

public class GoldCoinItem extends Item {
    public GoldCoinItem() {
        super(new Properties().stacksTo(64));
    }
}

