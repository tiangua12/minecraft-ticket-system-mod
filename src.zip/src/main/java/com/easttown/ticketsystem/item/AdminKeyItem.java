// AdminKeyItem.java
package com.easttown.ticketsystem.item;

import net.minecraft.world.item.Item;

public class AdminKeyItem extends Item {
    public AdminKeyItem(Properties properties) {
        super(properties);
    }
}