package com.easttown.ticketsystem.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;

public class TicketCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("ticketsystem")
                .requires(source -> source.hasPermission(4))
                .then(
                    Commands.literal("addstation")
                        .then(
                            Commands.argument("chineseName", StringArgumentType.string())
                                .then(
                                    Commands.argument("englishName", StringArgumentType.string())
                                        .then(
                                            Commands.argument("lineId", StringArgumentType.string())
                                                // 基本版本：只有三个参数
                                                .executes(
                                                    context -> AddStationCommand.executeFull(
                                                        context,
                                                        StringArgumentType.getString(context, "chineseName"),
                                                        StringArgumentType.getString(context, "englishName"),
                                                        StringArgumentType.getString(context, "lineId")
                                                    )
                                                )
                                                // 可选站序号
                                                .then(
                                                    Commands.argument("stationNumber", IntegerArgumentType.integer(0, 99))
                                                        .executes(
                                                            context -> AddStationCommand.executeFull(
                                                                context,
                                                                StringArgumentType.getString(context, "chineseName"),
                                                                StringArgumentType.getString(context, "englishName"),
                                                                StringArgumentType.getString(context, "lineId"),
                                                                IntegerArgumentType.getInteger(context, "stationNumber")
                                                            )
                                                        )
                                                        // 可选坐标
                                                        .then(
                                                            Commands.argument("x", IntegerArgumentType.integer())
                                                                .then(
                                                                    Commands.argument("y", IntegerArgumentType.integer())
                                                                        .then(
                                                                            Commands.argument("z", IntegerArgumentType.integer())
                                                                                .executes(
                                                                                    context -> AddStationCommand.executeFull(
                                                                                        context,
                                                                                        StringArgumentType.getString(context, "chineseName"),
                                                                                        StringArgumentType.getString(context, "englishName"),
                                                                                        StringArgumentType.getString(context, "lineId"),
                                                                                        IntegerArgumentType.getInteger(context, "stationNumber"),
                                                                                        IntegerArgumentType.getInteger(context, "x"),
                                                                                        IntegerArgumentType.getInteger(context, "y"),
                                                                                        IntegerArgumentType.getInteger(context, "z")
                                                                                    )
                                                                                )
                                                                        )
                                                                )
                                                        )
                                                )
                                        )
                                )
                        )
                )
                // 添加车站完整信息命令（中文名、英文名、线路ID）
                .then(
                    Commands.literal("addstationfull")
                        .then(
                            Commands.argument("chineseName", StringArgumentType.string())
                                .then(
                                    Commands.argument("englishName", StringArgumentType.string())
                                        .then(
                                            Commands.argument("lineId", StringArgumentType.string())
                                                // 基本版本：只有三个参数
                                                .executes(
                                                    context -> AddStationCommand.executeFull(
                                                        context,
                                                        StringArgumentType.getString(context, "chineseName"),
                                                        StringArgumentType.getString(context, "englishName"),
                                                        StringArgumentType.getString(context, "lineId")
                                                    )
                                                )
                                                // 可选站序号
                                                .then(
                                                    Commands.argument("stationNumber", IntegerArgumentType.integer(0, 99))
                                                        .executes(
                                                            context -> AddStationCommand.executeFull(
                                                                context,
                                                                StringArgumentType.getString(context, "chineseName"),
                                                                StringArgumentType.getString(context, "englishName"),
                                                                StringArgumentType.getString(context, "lineId"),
                                                                IntegerArgumentType.getInteger(context, "stationNumber")
                                                            )
                                                        )
                                                        // 可选坐标
                                                        .then(
                                                            Commands.argument("x", IntegerArgumentType.integer())
                                                                .then(
                                                                    Commands.argument("y", IntegerArgumentType.integer())
                                                                        .then(
                                                                            Commands.argument("z", IntegerArgumentType.integer())
                                                                                .executes(
                                                                                    context -> AddStationCommand.executeFull(
                                                                                        context,
                                                                                        StringArgumentType.getString(context, "chineseName"),
                                                                                        StringArgumentType.getString(context, "englishName"),
                                                                                        StringArgumentType.getString(context, "lineId"),
                                                                                        IntegerArgumentType.getInteger(context, "stationNumber"),
                                                                                        IntegerArgumentType.getInteger(context, "x"),
                                                                                        IntegerArgumentType.getInteger(context, "y"),
                                                                                        IntegerArgumentType.getInteger(context, "z")
                                                                                    )
                                                                                )
                                                                        )
                                                                )
                                                        )
                                                )
                                        )
                                )
                        )
                )
                // 修复点运算符位置和缺失的括号
                .then(
                    Commands.literal("deletestation")
                        .then(
                            Commands.argument("station", StringArgumentType.string())
                                .suggests((context, builder) -> DeleteStationCommand.getSuggestions(context, builder))
                                .executes(
                                    context -> DeleteStationCommand.execute(
                                        context,
                                        StringArgumentType.getString(context, "station")
                                    )
                                )
                        )
                )
                // 添加车站管理GUI命令
                .then(
                    Commands.literal("managestations")
                        .executes(ManageStationsCommand::execute)
                )
                // 添加重新加载配置命令
                .then(
                    Commands.literal("reload")
                        .executes(ReloadCommand::execute)
                )
                // 线路管理命令
                .then(
                    Commands.literal("line")
                        .then(
                            Commands.literal("create")
                                .then(
                                    Commands.argument("lineId", StringArgumentType.string())
                                        .then(
                                            Commands.argument("name", StringArgumentType.string())
                                                .then(
                                                    Commands.argument("color", StringArgumentType.string())
                                                        .executes(
                                                            context -> LineCreateCommand.execute(
                                                                context,
                                                                StringArgumentType.getString(context, "lineId"),
                                                                StringArgumentType.getString(context, "name"),
                                                                StringArgumentType.getString(context, "color")
                                                            )
                                                        )
                                                        // 可选英文名
                                                        .then(
                                                            Commands.argument("enName", StringArgumentType.string())
                                                                .executes(
                                                                    context -> LineCreateCommand.execute(
                                                                        context,
                                                                        StringArgumentType.getString(context, "lineId"),
                                                                        StringArgumentType.getString(context, "name"),
                                                                        StringArgumentType.getString(context, "enName"),
                                                                        StringArgumentType.getString(context, "color")
                                                                    )
                                                                )
                                                        )
                                                )
                                        )
                                )
                        )
                        .then(
                            Commands.literal("delete")
                                .then(
                                    Commands.argument("lineId", StringArgumentType.string())
                                        .executes(
                                            context -> LineDeleteCommand.execute(
                                                context,
                                                StringArgumentType.getString(context, "lineId")
                                            )
                                        )
                                )
                        )
                        .then(
                            Commands.literal("list")
                                .executes(LineListCommand::execute)
                        )
                        .then(
                            Commands.literal("info")
                                .then(
                                    Commands.argument("lineId", StringArgumentType.string())
                                        .executes(
                                            context -> LineInfoCommand.execute(
                                                context,
                                                StringArgumentType.getString(context, "lineId")
                                            )
                                        )
                                )
                        )
                )
                // Web服务器管理命令
                .then(
                    Commands.literal("startwebserver")
                        .executes(WebServerStartCommand::execute)
                )
                .then(
                    Commands.literal("stopwebserver")
                        .executes(WebServerStartCommand::executeStop)
                )
                .then(
                    Commands.literal("webserverstatus")
                        .executes(WebServerStartCommand::executeStatus)
                )
        );
    }
}
