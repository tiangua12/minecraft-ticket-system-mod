package com.easttown.ticketsystem.command;

import com.easttown.ticketsystem.manager.StationManager;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;

public class AddStationCommand {
    // 旧方法：不带坐标，默认坐标为0
    public static int execute(CommandContext<CommandSourceStack> context, String station) {
        return executeOld(context, station, 0, 0, 0);
    }

    // 旧方法：带坐标
    public static int execute(CommandContext<CommandSourceStack> context, String station, int x, int y, int z) {
        return executeOld(context, station, x, y, z);
    }

    // 旧方法实现
    private static int executeOld(CommandContext<CommandSourceStack> context, String station, int x, int y, int z) {
        // 添加车站坐标信息
        StationManager.addStation(station, x, y, z);
        context.getSource().sendSuccess(() ->
            Component.literal("已添加车站: " + station +
                (x == 0 && y == 0 && z == 0 ? "" : " 坐标: (" + x + ", " + y + ", " + z + ")")),
            true
        );
        return Command.SINGLE_SUCCESS;
    }

    // 新方法：完整信息，不带坐标
    public static int executeFull(CommandContext<CommandSourceStack> context,
                                 String chineseName, String englishName, String lineId) {
        return executeFull(context, chineseName, englishName, lineId, 0, 0, 0, 0);
    }

    // 新方法：完整信息，带站序号，不带坐标
    public static int executeFull(CommandContext<CommandSourceStack> context,
                                 String chineseName, String englishName, String lineId, int stationNumber) {
        return executeFull(context, chineseName, englishName, lineId, stationNumber, 0, 0, 0);
    }

    // 新方法：完整信息，带站序号和坐标
    public static int executeFull(CommandContext<CommandSourceStack> context,
                                 String chineseName, String englishName, String lineId,
                                 int stationNumber, int x, int y, int z) {
        boolean success = StationManager.addStationToLine(chineseName, englishName, lineId,
                                                         stationNumber, x, y, z);
        if (success) {
            String coordStr = (x == 0 && y == 0 && z == 0) ? "" :
                String.format(" 坐标: (%d, %d, %d)", x, y, z);
            String numberStr = stationNumber > 0 ? String.format(" (站序号: %02d)", stationNumber) : "";
            context.getSource().sendSuccess(() ->
                Component.literal(String.format("已添加车站: %s (%s) 到线路: %s%s%s",
                                               chineseName,
                                               englishName != null && !englishName.isEmpty() ? englishName : "无英文名",
                                               lineId, numberStr, coordStr)),
                true
            );
        } else {
            context.getSource().sendFailure(
                Component.literal("添加车站失败，请检查线路是否存在或编码是否冲突")
            );
        }
        return success ? Command.SINGLE_SUCCESS : 0;
    }
}