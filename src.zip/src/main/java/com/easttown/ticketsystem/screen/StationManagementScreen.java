package com.easttown.ticketsystem.screen;

import com.easttown.ticketsystem.TicketSystemMod;
import com.easttown.ticketsystem.data.Station;
import com.easttown.ticketsystem.manager.NetworkManager;
import com.easttown.ticketsystem.util.LanguageHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 车站管理屏幕
 * 显示所有车站列表，允许添加、删除、编辑车站
 */
@OnlyIn(Dist.CLIENT)
public class StationManagementScreen extends Screen {
    // 组件
    private EditBox searchBox;
    private Button addButton;
    private Button backButton;
    private Button refreshButton;

    // 数据
    private List<Station> allStations = new ArrayList<>();
    private List<Station> filteredStations = new ArrayList<>();

    // 显示区域
    private int scrollOffset = 0;
    private static final int ITEMS_PER_PAGE = 10;
    private static final int ITEM_HEIGHT = 20;

    public StationManagementScreen() {
        super(Component.literal("车站管理"));
    }

    @Override
    protected void init() {
        super.init();

        // 初始化网络管理器
        NetworkManager.initialize();

        // 加载车站数据
        loadStations();

        // 搜索框
        searchBox = new EditBox(
            this.font,
            this.width / 2 - 150, 40, 250, 20,
            Component.literal("搜索车站...")
        );
        searchBox.setResponder(text -> filterStations());
        this.addRenderableWidget(searchBox);

        // 刷新按钮
        refreshButton = Button.builder(
            Component.literal("刷新"),
            button -> {
                loadStations();
                filterStations();
            }
        )
        .pos(this.width / 2 + 110, 40)
        .size(40, 20)
        .build();
        this.addRenderableWidget(refreshButton);

        // 添加车站按钮
        addButton = Button.builder(
            Component.literal("添加车站"),
            button -> {
                Minecraft minecraft = Minecraft.getInstance();
                net.minecraft.core.BlockPos playerPos = minecraft.player != null ?
                    minecraft.player.blockPosition() : net.minecraft.core.BlockPos.ZERO;
                minecraft.setScreen(new AddStationScreen(playerPos));
            }
        )
        .pos(this.width / 2 - 100, this.height - 40)
        .size(100, 20)
        .build();
        this.addRenderableWidget(addButton);

        // 返回按钮
        backButton = Button.builder(
            Component.literal("返回"),
            button -> {
                this.onClose();
            }
        )
        .pos(this.width / 2 + 10, this.height - 40)
        .size(100, 20)
        .build();
        this.addRenderableWidget(backButton);

        // 上下滚动按钮
        Button scrollUpButton = Button.builder(
            Component.literal("↑"),
            button -> {
                if (scrollOffset > 0) scrollOffset--;
            }
        )
        .pos(this.width - 30, 70)
        .size(20, 20)
        .build();
        this.addRenderableWidget(scrollUpButton);

        Button scrollDownButton = Button.builder(
            Component.literal("↓"),
            button -> {
                int maxScroll = Math.max(0, filteredStations.size() - ITEMS_PER_PAGE);
                if (scrollOffset < maxScroll) scrollOffset++;
            }
        )
        .pos(this.width - 30, this.height - 50)
        .size(20, 20)
        .build();
        this.addRenderableWidget(scrollDownButton);
    }

    /**
     * 加载车站数据
     */
    private void loadStations() {
        allStations.clear();
        try {
            allStations.addAll(NetworkManager.getAllStations());
            // 按编码排序
            allStations.sort(Comparator.comparing(Station::getCode));
            TicketSystemMod.LOGGER.debug("Loaded {} stations", allStations.size());
        } catch (Exception e) {
            TicketSystemMod.LOGGER.error("Failed to load stations", e);
        }
        filteredStations = new ArrayList<>(allStations);
    }

    /**
     * 过滤车站列表
     */
    private void filterStations() {
        String query = searchBox.getValue().toLowerCase().trim();
        filteredStations.clear();

        if (query.isEmpty()) {
            filteredStations.addAll(allStations);
        } else {
            for (Station station : allStations) {
                if (station.getCode().toLowerCase().contains(query) ||
                    station.getName().toLowerCase().contains(query) ||
                    (station.getEnName() != null && station.getEnName().toLowerCase().contains(query))) {
                    filteredStations.add(station);
                }
            }
        }
        scrollOffset = 0; // 重置滚动
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        // 渲染背景
        this.renderBackground(guiGraphics);

        // 渲染标题
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 20, 0xFFFFFF);

        // 渲染搜索框标签
        guiGraphics.drawString(this.font, "搜索:", this.width / 2 - 170, 45, 0xFFFFFF, false);

        // 渲染车站列表标题
        int listTop = 70;
        guiGraphics.fill(this.width / 2 - 160, listTop - 5, this.width / 2 + 150, listTop + 15, 0x80000000);
        guiGraphics.drawString(this.font, "车站编码", this.width / 2 - 150, listTop, 0xFFFFFF, false);
        guiGraphics.drawString(this.font, "车站名称", this.width / 2 - 50, listTop, 0xFFFFFF, false);
        guiGraphics.drawString(this.font, "坐标 (X,Y,Z)", this.width / 2 + 50, listTop, 0xFFFFFF, false);
        guiGraphics.drawString(this.font, "操作", this.width / 2 + 150, listTop, 0xFFFFFF, false);

        // 渲染车站列表
        int startIndex = scrollOffset;
        int endIndex = Math.min(startIndex + ITEMS_PER_PAGE, filteredStations.size());

        for (int i = startIndex; i < endIndex; i++) {
            Station station = filteredStations.get(i);
            int yPos = listTop + 20 + (i - startIndex) * ITEM_HEIGHT;

            // 交替行背景色
            if ((i - startIndex) % 2 == 0) {
                guiGraphics.fill(this.width / 2 - 160, yPos - 2, this.width / 2 + 150, yPos + ITEM_HEIGHT - 2, 0x40000000);
            }

            // 车站信息
            guiGraphics.drawString(this.font, station.getCode(), this.width / 2 - 150, yPos, 0xFFFFFF, false);
            guiGraphics.drawString(this.font, station.getName(), this.width / 2 - 50, yPos, 0xFFFFFF, false);
            guiGraphics.drawString(this.font,
                String.format("%d, %d, %d", station.getX(), station.getY(), station.getZ()),
                this.width / 2 + 50, yPos, 0xFFFFFF, false);

            // 操作按钮（在每行渲染时动态创建，但这里简化显示）
            // 实际实现应使用Button组件，但为简化，使用文本按钮
            int buttonWidth = 40;
            int editX = this.width / 2 + 150;
            int deleteX = editX + buttonWidth + 5;

            // 编辑按钮（文本）
            guiGraphics.fill(editX, yPos - 2, editX + buttonWidth, yPos + ITEM_HEIGHT - 2, 0x80008000);
            guiGraphics.drawCenteredString(this.font, "编辑", editX + buttonWidth / 2, yPos, 0xFFFFFF);

            // 删除按钮（文本）
            guiGraphics.fill(deleteX, yPos - 2, deleteX + buttonWidth, yPos + ITEM_HEIGHT - 2, 0x80800000);
            guiGraphics.drawCenteredString(this.font, "删除", deleteX + buttonWidth / 2, yPos, 0xFFFFFF);

            // 检测点击
            if (mouseX >= editX && mouseX <= editX + buttonWidth &&
                mouseY >= yPos - 2 && mouseY <= yPos + ITEM_HEIGHT - 2) {
                // 鼠标悬停在编辑按钮上
                guiGraphics.renderTooltip(this.font, Component.literal("编辑车站"), mouseX, mouseY);
                if (Minecraft.getInstance().mouseHandler.isLeftPressed()) {
                    // 打开编辑屏幕（TODO: 实现）
                    TicketSystemMod.LOGGER.debug("Edit station: {}", station.getCode());
                }
            }

            if (mouseX >= deleteX && mouseX <= deleteX + buttonWidth &&
                mouseY >= yPos - 2 && mouseY <= yPos + ITEM_HEIGHT - 2) {
                // 鼠标悬停在删除按钮上
                guiGraphics.renderTooltip(this.font, Component.literal("删除车站"), mouseX, mouseY);
                if (Minecraft.getInstance().mouseHandler.isLeftPressed()) {
                    // 删除车站（TODO: 通过网络包）
                    TicketSystemMod.LOGGER.debug("Delete station: {}", station.getCode());
                }
            }
        }

        // 显示车站计数
        String countText = String.format("车站: %d/%d", filteredStations.size(), allStations.size());
        guiGraphics.drawString(this.font, countText, this.width / 2 - 150, this.height - 60, 0xFFFFFF, false);

        // 渲染滚动位置
        if (filteredStations.size() > ITEMS_PER_PAGE) {
            String scrollText = String.format("第 %d-%d 项，共 %d 项",
                startIndex + 1, endIndex, filteredStations.size());
            guiGraphics.drawString(this.font, scrollText, this.width / 2 + 50, this.height - 60, 0xFFFFFF, false);
        }

        // 渲染父类组件（按钮等）
        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void tick() {
        super.tick();
        searchBox.tick();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        super.onClose();
        // 返回上级屏幕（如果有）或关闭
    }
}