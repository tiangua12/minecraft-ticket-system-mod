package com.easttown.ticketsystem.block;

import com.easttown.ticketsystem.TicketSystemMod;
import com.easttown.ticketsystem.init.ItemInit;
import com.easttown.ticketsystem.init.BlockEntityInit;
import com.easttown.ticketsystem.screen.TravelServiceTerminalMenu;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.resources.ResourceLocation;
import com.easttown.ticketsystem.item.TicketItem;
import com.easttown.ticketsystem.manager.CoinSystem;
import com.easttown.ticketsystem.manager.PriceCalculator;
import com.easttown.ticketsystem.manager.StationManager;
import com.easttown.ticketsystem.util.LanguageHelper;
import net.minecraft.core.Direction;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TravelServiceTerminalBlockEntity extends BlockEntity implements MenuProvider {
    // 操作类型枚举
    public enum OperationType {
        REFUND,         // 退票
        SUPPLEMENT,     // 补票
        CHANGE,         // 改签
        REIMBURSE       // 报销凭证打印
    }
    
    // 物品槽位
    private static final int TICKET_SLOT = 0;        // 车票输入槽
    private static final int OUTPUT_SLOT = 1;        // 输出槽
    
    private final ItemStackHandler itemHandler = new ItemStackHandler(2) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
            if (level != null && !level.isClientSide) {
                level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
            }
        }
        
        @Override
        public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
            // 只允许在车票槽放入车票
            return slot == TICKET_SLOT && stack.getItem() instanceof TicketItem;
        }
    };
    
    private LazyOptional<IItemHandler> lazyItemHandler = LazyOptional.empty();
    
    // 硬币存储系统
    private final Map<String, Integer> storedCoins = new HashMap<>();
    
    // 当前操作类型
    private OperationType currentOperation = OperationType.REFUND;
    
    // 改签时选择的新目的地
    private String newDestination = "";
    
    // 当前玩家（用于操作）
    private ServerPlayer currentPlayer;

    public TravelServiceTerminalBlockEntity(BlockPos pos, BlockState state) {
        super(BlockEntityInit.TRAVEL_SERVICE_TERMINAL.get(), pos, state);
    }
    
    @Override
    public Component getDisplayName() {
        return Component.translatable("block.ticketsystem.travel_service_terminal");
    }
    
    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new TravelServiceTerminalMenu(containerId, inventory, this, player instanceof ServerPlayer ? (ServerPlayer) player : null);
    }
    
    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) {
            return lazyItemHandler.cast();
        }
        return super.getCapability(cap, side);
    }
    
    @Override
    public void onLoad() {
        super.onLoad();
        lazyItemHandler = LazyOptional.of(() -> itemHandler);
    }
    
    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        lazyItemHandler.invalidate();
    }
    
    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("inventory", itemHandler.serializeNBT());
        
        // 保存硬币存储
        CompoundTag coinsTag = new CompoundTag();
        for (Map.Entry<String, Integer> entry : storedCoins.entrySet()) {
            coinsTag.putInt(entry.getKey(), entry.getValue());
        }
        tag.put("StoredCoins", coinsTag);
        
        // 保存操作类型
        tag.putString("OperationType", currentOperation.name());
        
        // 保存新目的地
        tag.putString("NewDestination", newDestination);
    }
    
    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        itemHandler.deserializeNBT(tag.getCompound("inventory"));
        
        // 加载硬币存储
        storedCoins.clear();
        CompoundTag coinsTag = tag.getCompound("StoredCoins");
        for (String key : coinsTag.getAllKeys()) {
            storedCoins.put(key, coinsTag.getInt(key));
        }
        
        // 加载操作类型
        if (tag.contains("OperationType")) {
            currentOperation = OperationType.valueOf(tag.getString("OperationType"));
        }
        
        // 加载新目的地
        if (tag.contains("NewDestination")) {
            newDestination = tag.getString("NewDestination");
        }
    }
    
    // 设置操作类型
    public void setOperationType(OperationType type) {
        if (currentOperation != type) {
            currentOperation = type;
            setChanged();
            if (level != null) {
                level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
            }
        }
    }
    
    public OperationType getOperationType() {
        return currentOperation;
    }
    
    // 设置新目的地
    public void setNewDestination(String destination) {
        if (destination != null && !destination.equals(newDestination)) {
            newDestination = destination;
            setChanged();
            if (level != null) {
                level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
            }
        }
    }
    
    public String getNewDestination() {
        return newDestination;
    }
    
    // 添加硬币到存储
    public void addCoins(Map<String, Integer> coins) {
        for (Map.Entry<String, Integer> entry : coins.entrySet()) {
            String coinId = entry.getKey();
            int amount = entry.getValue();
            storedCoins.put(coinId, storedCoins.getOrDefault(coinId, 0) + amount);
        }
        setChanged();
    }
    
    // 取出所有存储的硬币
    public Map<String, Integer> withdrawCoins() {
        Map<String, Integer> coins = new HashMap<>(storedCoins);
        storedCoins.clear();
        setChanged();
        return coins;
    }
    
    // 获取存储的硬币
    public Map<String, Integer> getStoredCoins() {
        return Collections.unmodifiableMap(storedCoins);
    }
    
    // 获取硬币总价值（以铜币为单位）
    public int getTotalCopperValue() {
        int total = 0;
        for (Map.Entry<String, Integer> entry : storedCoins.entrySet()) {
            String coinId = entry.getKey();
            int amount = entry.getValue();
            int valuePerCoin = CoinSystem.getCoinValue(coinId);
            total += valuePerCoin * amount;
        }
        return total;
    }
    
    // 执行操作
    public void performOperation(ServerPlayer player) {
        this.currentPlayer = player;
        ItemStack ticketStack = itemHandler.getStackInSlot(TICKET_SLOT);
        
        if (ticketStack.isEmpty() || !(ticketStack.getItem() instanceof TicketItem)) {
            player.displayClientMessage(LanguageHelper.translate("ticketsystem.terminal.no_ticket"), false);
            return;
        }
        
        CompoundTag ticketTag = ticketStack.getOrCreateTag();
        
        switch (currentOperation) {
            case REFUND:
                processRefund(ticketStack, ticketTag);
                break;
            case SUPPLEMENT:
                processSupplement(ticketStack, ticketTag);
                break;
            case CHANGE:
                processChange(ticketStack, ticketTag);
                break;
            case REIMBURSE:
                processReimbursement(ticketStack, ticketTag);
                break;
        }
        
        setChanged();
    }
    
    // 处理退票
    private void processRefund(ItemStack ticketStack, CompoundTag ticketTag) {
        String status = ticketTag.getString("Status");
        int originalPrice = ticketTag.getInt("Price");
        
        // 计算退款金额（根据状态）
        int refundAmount;
        if (TicketItem.UNUSED.equals(status)) {
            refundAmount = (int) (originalPrice * 0.8); // 未使用票退80%
        } else if (TicketItem.IN_USE.equals(status)) {
            // 计算已用时间比例
            long issueTime = ticketTag.getLong("IssueTime");
            long currentTime = System.currentTimeMillis();
            double timeRatio = Math.min(1.0, (currentTime - issueTime) / 3600000.0); // 按小时计算
            
            refundAmount = (int) (originalPrice * (0.5 - timeRatio * 0.3)); // 已使用票退20%-50%
        } else {
            currentPlayer.displayClientMessage(LanguageHelper.translate("ticketsystem.terminal.invalid_refund"), false);
            return;
        }
        
        // 检查库存是否足够退款
        if (getTotalCopperValue() < refundAmount) {
            currentPlayer.displayClientMessage(LanguageHelper.translate("ticketsystem.terminal.insufficient_coins"), false);
            return;
        }
        
        // 退款并销毁车票
        refundCoins(refundAmount);
        ticketStack.shrink(1); // 销毁车票
        
        currentPlayer.displayClientMessage(
            LanguageHelper.translate("ticketsystem.terminal.refund_success", refundAmount), 
            false
        );
    }
    
    // 处理补票
    private void processSupplement(ItemStack ticketStack, CompoundTag ticketTag) {
        if (!TicketItem.IN_USE.equals(ticketTag.getString("Status"))) {
            currentPlayer.displayClientMessage(LanguageHelper.translate("ticketsystem.terminal.invalid_supplement"), false);
            return;
        }
        
        // 计算补票金额（固定手续费或百分比）
        int supplementAmount = 100; // 固定手续费100铜币
        
        // 从玩家身上扣款
        if (!CoinSystem.hasSufficientCoins(currentPlayer, supplementAmount)) {
            currentPlayer.displayClientMessage(LanguageHelper.translate("ticketsystem.terminal.insufficient_player_coins"), false);
            return;
        }
        
        Map<String, Integer> paidCoins = CoinSystem.deductWithChange(currentPlayer, supplementAmount);
        addCoins(paidCoins);
        
        // 标记车票已补
        ticketTag.putBoolean("Supplemented", true);
        
        currentPlayer.displayClientMessage(
            LanguageHelper.translate("ticketsystem.terminal.supplement_success", supplementAmount), 
            false
        );
    }
    
    // 处理改签
    private void processChange(ItemStack ticketStack, CompoundTag ticketTag) {
        if (newDestination.isEmpty()) {
            currentPlayer.displayClientMessage(LanguageHelper.translate("ticketsystem.terminal.no_destination"), false);
            return;
        }
        
        if (!StationManager.containsStation(newDestination)) {
            currentPlayer.displayClientMessage(
                LanguageHelper.translate("ticketsystem.terminal.invalid_destination", newDestination), 
                false
            );
            return;
        }
        
        String startStation = ticketTag.getString("StartStation");
        String oldDestination = ticketTag.getString("Destination");
        int oldPrice = ticketTag.getInt("Price");
        
        // 计算新价格
        int newPrice = PriceCalculator.calculatePrice(startStation, newDestination);
        
        // 计算差价
        int priceDifference = newPrice - oldPrice;
        
        if (priceDifference > 0) {
            // 需要补差价
            if (!CoinSystem.hasSufficientCoins(currentPlayer, priceDifference)) {
                currentPlayer.displayClientMessage(
                    LanguageHelper.translate("ticketsystem.terminal.insufficient_player_coins"),
                    false
                );
                return;
            }
            
            Map<String, Integer> paidCoins = CoinSystem.deductWithChange(currentPlayer, priceDifference);
            addCoins(paidCoins);
        } else if (priceDifference < 0) {
            // 需要退差价
            int refundAmount = -priceDifference;
            if (getTotalCopperValue() < refundAmount) {
                currentPlayer.displayClientMessage(
                    LanguageHelper.translate("ticketsystem.terminal.insufficient_coins"),
                    false
                );
                return;
            }
            
            refundCoins(refundAmount);
        }
        
        // 更新车票信息
        ticketTag.putString("Destination", newDestination);
        ticketTag.putInt("Price", newPrice);
        ticketTag.putLong("ChangeTime", System.currentTimeMillis());
        
        currentPlayer.displayClientMessage(
            LanguageHelper.translate("ticketsystem.terminal.change_success", newDestination, Math.abs(priceDifference), priceDifference > 0 ? "paid" : "refunded"), 
            false
        );
    }
    
    // 处理报销凭证打印
    private void processReimbursement(ItemStack ticketStack, CompoundTag ticketTag) {
        if (!TicketItem.COMPLETED.equals(ticketTag.getString("Status"))) {
            currentPlayer.displayClientMessage(LanguageHelper.translate("ticketsystem.terminal.invalid_reimbursement"), false);
            return;
        }
        
        // 检查输出槽是否为空
        if (!itemHandler.getStackInSlot(OUTPUT_SLOT).isEmpty()) {
            currentPlayer.displayClientMessage(LanguageHelper.translate("ticketsystem.terminal.output_occupied"), false);
            return;
        }
        
        // 创建报销凭证
        ItemStack voucher = new ItemStack(ItemInit.REIMBURSEMENT_VOUCHER.get());
        CompoundTag voucherTag = ticketTag.copy();
        voucherTag.putBoolean("IsReimbursement", true);
        voucher.setTag(voucherTag);
        
        // 放入输出槽
        itemHandler.setStackInSlot(OUTPUT_SLOT, voucher);
        
        // 销毁原车票
        ticketStack.shrink(1);
        
        currentPlayer.displayClientMessage(
            LanguageHelper.translate("ticketsystem.terminal.reimbursement_success"), 
            false
        );
    }
    
    // 退款硬币给玩家
private void refundCoins(int refundAmount) {
    Map<String, Integer> refundCoins = CoinSystem.calculateOptimalCoins(refundAmount);
    
    // 验证库存是否足够
    for (Map.Entry<String, Integer> entry : refundCoins.entrySet()) {
        String coinId = entry.getKey();
        int amount = entry.getValue();
        if (storedCoins.getOrDefault(coinId, 0) < amount) {
            currentPlayer.displayClientMessage(
                LanguageHelper.translate("ticketsystem.terminal.insufficient_coins"),
                false
            );
            return;
        }
    }
    
    // 扣除库存
    for (Map.Entry<String, Integer> entry : refundCoins.entrySet()) {
        String coinId = entry.getKey();
        int amount = entry.getValue();
        storedCoins.put(coinId, storedCoins.get(coinId) - amount);
    }
    
    // 给予玩家硬币
    for (Map.Entry<String, Integer> entry : refundCoins.entrySet()) {
        String coinId = entry.getKey();
        Item coinItem = ForgeRegistries.ITEMS.getValue(ResourceLocation.tryParse(coinId));
        if (coinItem != null) {
            // 修复 giveItems 调用
CoinSystem.giveItems(currentPlayer, coinItem, entry.getValue());

        }
    }
}

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag);
        return tag;
    }
    
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
    
    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        super.onDataPacket(net, pkt);
        handleUpdateTag(pkt.getTag());
    }
    // 替换为：
private void giveCoinsToPlayer(Map<String, Integer> coins) {
    for (Map.Entry<String, Integer> entry : coins.entrySet()) {
        Item coinItem = ForgeRegistries.ITEMS.getValue(ResourceLocation.tryParse(entry.getKey()));
        if (coinItem != null) {
            CoinSystem.giveItems(currentPlayer, coinItem, entry.getValue());
        }
    }
}

}
