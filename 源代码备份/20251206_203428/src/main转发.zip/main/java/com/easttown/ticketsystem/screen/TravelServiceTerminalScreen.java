package com.easttown.ticketsystem.screen;

import com.easttown.ticketsystem.TicketSystemMod;
import com.easttown.ticketsystem.block.TravelServiceTerminalBlockEntity;
import com.easttown.ticketsystem.block.TravelServiceTerminalBlockEntity.OperationType;
import com.easttown.ticketsystem.client.UserStationList;
import com.easttown.ticketsystem.manager.CoinSystem;
import com.easttown.ticketsystem.network.NetworkHandler;
import com.easttown.ticketsystem.network.TerminalOperationPacket;
import com.easttown.ticketsystem.util.LanguageHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

import java.util.Map;

public class TravelServiceTerminalScreen extends AbstractContainerScreen<TravelServiceTerminalMenu> {
    // 布局常量
    private static final int WIDTH = 256;
    private static final int HEIGHT = 220;
    private static final ResourceLocation TEXTURE = 
        ResourceLocation.fromNamespaceAndPath(TicketSystemMod.MODID, "textures/gui/travel_service_terminal.png");
    
    // 操作按钮布局
    private static final int OPERATION_BUTTONS_X = 10;
    private static final int BUTTON_SPACING = 25;
    private static final int BUTTON_WIDTH = 100; // 加宽以适应中文
    private static final int BUTTON_HEIGHT = 20;
    
    // 按钮Y位置
    private static final int REFUND_BUTTON_Y = 60;
    private static final int SUPPLEMENT_BUTTON_Y = REFUND_BUTTON_Y + BUTTON_SPACING;
    private static final int CHANGE_BUTTON_Y = SUPPLEMENT_BUTTON_Y + BUTTON_SPACING;
    private static final int REIMBURSE_BUTTON_Y = CHANGE_BUTTON_Y + BUTTON_SPACING;
    private static final int OPERATE_BUTTON_Y = REIMBURSE_BUTTON_Y + BUTTON_SPACING + 5;
    
    // 车站列表位置
    private static final int STATION_LIST_X = 170;
    private static final int STATION_LIST_Y = 20;
    private static final int STATION_LIST_WIDTH = 120;
    private static final int STATION_LIST_HEIGHT = 120;
    
    // 硬币显示位置
    private static final int COINS_X = 170;
    private static final int COINS_Y = 150;
    private static final int COINS_WIDTH = 80;
    private static final int COINS_HEIGHT = 60;
    
    // UI组件
    private Button refundButton, supplementButton, changeButton, reimburseButton, operateButton;
    private final UserStationList stationList;
    private final boolean isAdmin;
    
    // 状态变量
    private String selectedStation = ""; // 当前选中的车站

    public TravelServiceTerminalScreen(TravelServiceTerminalMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = WIDTH;
        this.imageHeight = HEIGHT;
        this.isAdmin = menu.getPlayer() != null;
        
        // 初始化车站列表
        this.stationList = new UserStationList(
            null,
            0, 0, 
            STATION_LIST_WIDTH, 
            STATION_LIST_HEIGHT
        );
    }

    @Override
    protected void init() {
        super.init();
        this.leftPos = (this.width - imageWidth) / 2;
        this.topPos = (this.height - imageHeight) / 2;
        
        // 创建操作按钮
        refundButton = Button.builder(
                LanguageHelper.translate("ticketsystem.terminal.refund"), 
                button -> setOperationType(OperationType.REFUND))
            .bounds(leftPos + OPERATION_BUTTONS_X, topPos + REFUND_BUTTON_Y, BUTTON_WIDTH, BUTTON_HEIGHT)
            .build();
        addRenderableWidget(refundButton);
        
        supplementButton = Button.builder(
                LanguageHelper.translate("ticketsystem.terminal.supplement"), 
                button -> setOperationType(OperationType.SUPPLEMENT))
            .bounds(leftPos + OPERATION_BUTTONS_X, topPos + SUPPLEMENT_BUTTON_Y, BUTTON_WIDTH, BUTTON_HEIGHT)
            .build();
        addRenderableWidget(supplementButton);
        
        changeButton = Button.builder(
                LanguageHelper.translate("ticketsystem.terminal.change"), 
                button -> setOperationType(OperationType.CHANGE))
            .bounds(leftPos + OPERATION_BUTTONS_X, topPos + CHANGE_BUTTON_Y, BUTTON_WIDTH, BUTTON_HEIGHT)
            .build();
        addRenderableWidget(changeButton);
        
        reimburseButton = Button.builder(
                LanguageHelper.translate("ticketsystem.terminal.reimburse"), 
                button -> setOperationType(OperationType.REIMBURSE))
            .bounds(leftPos + OPERATION_BUTTONS_X, topPos + REIMBURSE_BUTTON_Y, BUTTON_WIDTH, BUTTON_HEIGHT)
            .build();
        addRenderableWidget(reimburseButton);
        
        operateButton = Button.builder(
                LanguageHelper.translate("ticketsystem.terminal.operate"), 
                button -> performOperation())
            .bounds(leftPos + OPERATION_BUTTONS_X, topPos + OPERATE_BUTTON_Y, BUTTON_WIDTH, BUTTON_HEIGHT)
            .build();
        addRenderableWidget(operateButton);
        
        // 设置车站列表位置和点击监听器
        stationList.setPosition(
            leftPos + STATION_LIST_X, 
            topPos + STATION_LIST_Y, 
            STATION_LIST_WIDTH, 
            STATION_LIST_HEIGHT
        );
        
        // 添加车站选择监听器
        stationList.setOnClick(station -> {
            this.selectedStation = station;
            
            // 如果是改签操作，立即设置新目的地
            if (menu.getBlockEntity().getOperationType() == OperationType.CHANGE) {
                menu.getBlockEntity().setNewDestination(station);
            }
        });
        
        // 刷新车站数据
        stationList.refreshStations("");
        addRenderableWidget(stationList);
        
        // 更新按钮状态
        updateButtonStates();
    }
    
    private void setOperationType(OperationType type) {
        menu.getBlockEntity().setOperationType(type);
        updateButtonStates();
    }
    
    private void updateButtonStates() {
        OperationType currentType = menu.getBlockEntity().getOperationType();
        
        // 更新操作按钮状态
        refundButton.active = currentType != OperationType.REFUND;
        supplementButton.active = currentType != OperationType.SUPPLEMENT;
        changeButton.active = currentType != OperationType.CHANGE;
        reimburseButton.active = currentType != OperationType.REIMBURSE;
        
        // 改签操作时才显示车站列表
        stationList.setVisible(currentType == OperationType.CHANGE);
    }
    
    private void performOperation() {
        // 发送操作包
        NetworkHandler.sendToServer(new TerminalOperationPacket(menu.getBlockEntity().getBlockPos()));
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
        // 渲染背景纹理
        guiGraphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
        
        // 绘制硬币信息
        if (isAdmin) {
            renderCoinInfo(guiGraphics);
        }
    }
    
    private void renderCoinInfo(GuiGraphics guiGraphics) {
        TravelServiceTerminalBlockEntity blockEntity = menu.getBlockEntity();
        int totalValue = blockEntity.getTotalCopperValue();
        Map<String, Integer> storedCoins = blockEntity.getStoredCoins();
        
        // 背景
        guiGraphics.fill(leftPos + COINS_X, topPos + COINS_Y, 
                         leftPos + COINS_X + COINS_WIDTH, topPos + COINS_Y + COINS_HEIGHT, 
                         0xAAFFFF00);
        
        // 标题
        guiGraphics.drawString(font, 
            LanguageHelper.translate("ticketsystem.terminal.coins"), 
            leftPos + COINS_X + 5, topPos + COINS_Y + 5, 
            0x000000, false);
        
        // 总价值
        guiGraphics.drawString(font, 
            LanguageHelper.translate("ticketsystem.terminal.total_value", totalValue), 
            leftPos + COINS_X + 5, topPos + COINS_Y + 20, 
            0x000000, false);
        
        // 各种硬币数量
        int yOffset = 35;
        for (Map.Entry<String, Integer> entry : storedCoins.entrySet()) {
            if (entry.getValue() > 0) {
                String coinName = CoinSystem.getCoinName(entry.getKey());
                guiGraphics.drawString(font, 
                    coinName + ": " + entry.getValue(), 
                    leftPos + COINS_X + 5, topPos + COINS_Y + yOffset, 
                    0x000000, false);
                yOffset += 10;
            }
        }
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        // 标题
        guiGraphics.drawString(font, title, 8, 6, 0x404040, false);
        
        TravelServiceTerminalBlockEntity blockEntity = menu.getBlockEntity();
        
        // 当前操作类型
        OperationType currentType = blockEntity.getOperationType();
        guiGraphics.drawString(font, 
            LanguageHelper.translate("ticketsystem.terminal.current_operation") + ": " + 
            LanguageHelper.translate("ticketsystem.terminal." + currentType.name().toLowerCase()), 
            10, 20, 0x000000, false);
        
        // 改签时显示新目的地
        if (currentType == OperationType.CHANGE) {
            String destination = blockEntity.getNewDestination();
            if (destination != null && !destination.isEmpty()) {
                guiGraphics.drawString(font, 
                    LanguageHelper.translate("ticketsystem.terminal.selected_destination") + ": " + destination, 
                    10, 35, 0x000000, false);
            }
        }
        
        // 显示当前选中的车站
        if (!selectedStation.isEmpty()) {
            guiGraphics.drawString(font, 
                LanguageHelper.translate("ticketsystem.terminal.selected_station") + ": " + selectedStation, 
                10, 50, 0x000000, false);
        }
    }
    
    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        renderBackground(guiGraphics);
        super.render(guiGraphics, mouseX, mouseY, partialTicks);
        renderTooltip(guiGraphics, mouseX, mouseY);
        
        // 更新车站列表位置
        stationList.setPosition(
            leftPos + STATION_LIST_X, 
            topPos + STATION_LIST_Y, 
            STATION_LIST_WIDTH, 
            STATION_LIST_HEIGHT
        );
    }
    
    // 设置选中的车站
    public void setSelectedStation(String station) {
        this.selectedStation = station;
    }
    
    // 获取选中的车站
    public String getSelectedStation() {
        return selectedStation;
    }
}
