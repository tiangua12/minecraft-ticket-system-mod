package com.easttown.ticketsystem.network;

import com.easttown.ticketsystem.block.TravelServiceTerminalBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class TerminalOperationPacket {
    private final BlockPos pos;
    
    public TerminalOperationPacket(BlockPos pos) {
        this.pos = pos;
    }
    
    public static void encode(TerminalOperationPacket packet, FriendlyByteBuf buffer) {
        buffer.writeBlockPos(packet.pos);
    }
    
    public static TerminalOperationPacket decode(FriendlyByteBuf buffer) {
        return new TerminalOperationPacket(buffer.readBlockPos());
    }
    
    public static void handle(TerminalOperationPacket packet, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() -> {
            ServerPlayer player = context.get().getSender();
            if (player != null) {
                if (player.level() instanceof ServerLevel level) {
                    if (level.getBlockEntity(packet.pos) instanceof TravelServiceTerminalBlockEntity terminal) {
                        terminal.performOperation(player);
                    }
                }
            }
        });
        context.get().setPacketHandled(true);
    }
}
