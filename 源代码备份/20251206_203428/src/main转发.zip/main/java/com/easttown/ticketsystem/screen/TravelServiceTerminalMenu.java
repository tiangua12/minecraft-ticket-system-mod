package com.easttown.ticketsystem.screen;

import com.easttown.ticketsystem.block.TravelServiceTerminalBlockEntity;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import com.easttown.ticketsystem.item.TicketItem;
import com.easttown.ticketsystem.init.MenuInit;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

public class TravelServiceTerminalMenu extends AbstractContainerMenu {
    private final TravelServiceTerminalBlockEntity blockEntity;
    private final ServerPlayer player;
    
    public TravelServiceTerminalMenu(int containerId, Inventory inventory, TravelServiceTerminalBlockEntity blockEntity, ServerPlayer player) {
        super(MenuInit.TRAVEL_SERVICE_TERMINAL.get(), containerId);
        this.blockEntity = blockEntity;
        this.player = player;
        
        // 添加玩家物品栏
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        
        // 添加玩家快捷栏
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inventory, col, 8 + col * 18, 142));
        }
        
        // 添加终端槽位
        IItemHandler handler = blockEntity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).orElse(null);
        if (handler != null) {
            // 车票输入槽
            this.addSlot(new SlotItemHandler(handler, 0, 44, 34) {
                @Override
                public boolean mayPlace(ItemStack stack) {
                    return stack.getItem() instanceof TicketItem;
                }
            });
            
            // 输出槽
            this.addSlot(new SlotItemHandler(handler, 1, 116, 34) {
                @Override
                public boolean mayPlace(ItemStack stack) {
                    return false; // 不允许放入物品
                }
            });
        }
    }
    
    public TravelServiceTerminalMenu(int containerId, Inventory inventory, FriendlyByteBuf extraData) {
        this(containerId, inventory, 
            (TravelServiceTerminalBlockEntity) inventory.player.level().getBlockEntity(extraData.readBlockPos()),
            extraData.readBoolean() ? (ServerPlayer) inventory.player : null);
    }
    
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }
    
    @Override
    public boolean stillValid(Player player) {
        return blockEntity != null && !blockEntity.isRemoved();
    }
    
    public TravelServiceTerminalBlockEntity getBlockEntity() {
        return blockEntity;
    }
    
    public ServerPlayer getPlayer() {
        return player;
    }
}
