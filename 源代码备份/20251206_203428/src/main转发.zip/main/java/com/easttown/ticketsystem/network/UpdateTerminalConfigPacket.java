package com.easttown.ticketsystem.network;

import com.easttown.ticketsystem.block.TravelServiceTerminalBlockEntity;
import com.easttown.ticketsystem.block.TravelServiceTerminalBlockEntity.OperationType;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class UpdateTerminalConfigPacket {
    private final BlockPos pos;
    private final OperationType operationType;
    private final String destination;
    
    public UpdateTerminalConfigPacket(BlockPos pos, OperationType operationType, String destination) {
        this.pos = pos;
        this.operationType = operationType;
        this.destination = destination;
    }
    
    public static void encode(UpdateTerminalConfigPacket packet, FriendlyByteBuf buffer) {
        buffer.writeBlockPos(packet.pos);
        buffer.writeEnum(packet.operationType);
        buffer.writeUtf(packet.destination);
    }
    
    public static UpdateTerminalConfigPacket decode(FriendlyByteBuf buffer) {
        return new UpdateTerminalConfigPacket(
            buffer.readBlockPos(),
            buffer.readEnum(OperationType.class),
            buffer.readUtf()
        );
    }
    
    public static void handle(UpdateTerminalConfigPacket packet, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() -> {
            ServerLevel level = (ServerLevel) context.get().getSender().level();
            if (level.getBlockEntity(packet.pos) instanceof TravelServiceTerminalBlockEntity terminal) {
                terminal.setOperationType(packet.operationType);
                terminal.setNewDestination(packet.destination);
            }
        });
        context.get().setPacketHandled(true);
    }
}
