// DiamondCoinItem.java
package com.easttown.ticketsystem.item;

import net.minecraft.world.item.Item;

public class DiamondCoinItem extends Item {
    public DiamondCoinItem() {
        super(new Properties().stacksTo(64));
    }
}

