package com.easttown.ticketsystem.screen;

import com.easttown.ticketsystem.TicketSystemMod;
import com.easttown.ticketsystem.block.TravelServiceTerminalBlockEntity;
import com.easttown.ticketsystem.init.MenuInit;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.IItemHandler;

public class TravelServiceTerminalMenu extends AbstractContainerMenu {

    // 物品栏位置变量
    private int inventoryX = 8;
    private int inventoryY = 18+18*6+14;
    private final IItemHandler itemHandler;

    public TravelServiceTerminalMenu(int containerId, Inventory inventory, FriendlyByteBuf extraData) {
        this(containerId, inventory, extraData != null ? extraData.readBlockPos() : BlockPos.ZERO);
    }

    public TravelServiceTerminalMenu(int containerId, Inventory inventory, BlockPos pos) {
        super(MenuInit.TRAVEL_SERVICE_TERMINAL.get(), containerId);
        
        // 如果pos是ZERO（表示data为null），则不初始化itemHandler
        if (!pos.equals(BlockPos.ZERO)) {
            BlockEntity blockEntity = inventory.player.level().getBlockEntity(pos);
            if (blockEntity instanceof TravelServiceTerminalBlockEntity terminal) {
                // 直接使用方块实体提供的方法获取物品处理器，避免capability系统的问题
                this.itemHandler = terminal.getItemHandler();
                if (this.itemHandler == null) {
                    TicketSystemMod.LOGGER.warn("旅行服务终端方块实体物品处理器为null，位置: {}", pos);
                }
            } else {
                this.itemHandler = null;
                TicketSystemMod.LOGGER.warn("在位置 {} 未找到旅行服务终端方块实体", pos);
            }
        } else {
            this.itemHandler = null;
            TicketSystemMod.LOGGER.debug("旅行服务终端菜单使用默认构造，itemHandler为null");
        }
        
        // 添加终端槽位
        addTerminalSlots();
        // 添加玩家物品栏槽位
        addPlayerInventory(inventory);
    }

    public TravelServiceTerminalMenu(int containerId, Inventory inventory, int inventoryX, int inventoryY) {
        super(MenuInit.TRAVEL_SERVICE_TERMINAL.get(), containerId);
        this.inventoryX = inventoryX;
        this.inventoryY = inventoryY;
        this.itemHandler = null;
        
        // 添加玩家物品栏槽位
        addPlayerInventory(inventory);
    }

    /**
     * 添加终端专用槽位
     */
    private void addTerminalSlots() {
        if (itemHandler != null) {
            // 输入槽 (槽位0) - 只能放入车票 - 放在GUI上半部分居中位置
            this.addSlot(new TerminalSlot(itemHandler, 0, 80, 20, true));
            // 输出槽 (槽位1) - 不能放入物品 - 放在输入槽下方
            this.addSlot(new TerminalSlot(itemHandler, 1, 80, 50, false));
        } else {
            TicketSystemMod.LOGGER.debug("旅行服务终端物品处理器为null，跳过添加终端槽位");
        }
    }

    /**
     * 添加玩家物品栏和快捷栏
     */
    private void addPlayerInventory(Inventory inventory) {
        final int SLOT_SIZE = 18; // 每个槽位的大小
        final int COLUMNS = 9; // 物品栏列数
        
        // 添加快捷栏 (槽位索引0-8)
        for (int col = 0; col < COLUMNS; col++) {
            int x = inventoryX + col * SLOT_SIZE;
            this.addSlot(new Slot(inventory, col, x, inventoryY + 58)); // 快捷栏在物品栏下方
        }
        
        // 添加主物品栏 (槽位索引9-35)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                int slotIndex = col + row * COLUMNS + COLUMNS; // +9跳过快捷栏
                int x = inventoryX + col * SLOT_SIZE;
                int y = inventoryY + row * SLOT_SIZE;
                this.addSlot(new Slot(inventory, slotIndex, x, y));
            }
        }
        
        
        
        
        
        
        
        
    }
    
    // 设置物品栏位置的方法（供屏幕调用）
    public void setInventoryPosition(int x, int y) {
        this.inventoryX = x;
        this.inventoryY = y;
    }
    
    // 获取物品栏位置的方法
    public int getInventoryX() {
        return inventoryX;
    }
    
    public int getInventoryY() {
        return inventoryY;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public net.minecraft.world.item.ItemStack quickMoveStack(Player player, int index) {
   /*     net.minecraft.world.item.ItemStack itemstack = net.minecraft.world.item.ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        
        if (slot != null && slot.hasItem()) {
            net.minecraft.world.item.ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.copy();
            
            // 从终端槽位移到玩家物品栏
            if (index < 2) {
                if (!this.moveItemStackTo(itemstack1, 2, this.slots.size(), true)) {
                    return net.minecraft.world.item.ItemStack.EMPTY;
                }
            } 
            // 从玩家物品栏移到终端槽位
            else {
                // 只能将车票移到输入槽
                if (itemstack1.getItem() instanceof com.easttown.ticketsystem.item.TicketItem) {
                    if (!this.moveItemStackTo(itemstack1, 0, 1, false)) {
                        return net.minecraft.world.item.ItemStack.EMPTY;
                    }
                }
            }
            
            if (itemstack1.isEmpty()) {
                slot.set(net.minecraft.world.item.ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        
        return itemstack;  */
        
        return net.minecraft.world.item.ItemStack.EMPTY;
    }
}
