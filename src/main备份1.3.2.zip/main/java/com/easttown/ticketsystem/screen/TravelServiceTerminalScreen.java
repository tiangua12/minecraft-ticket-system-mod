package com.easttown.ticketsystem.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class TravelServiceTerminalScreen extends AbstractContainerScreen<TravelServiceTerminalMenu> {
    
    // 使用大箱子贴图 (generic_54.png)
    private static final ResourceLocation TEXTURE = ResourceLocation.parse("textures/gui/container/generic_54.png");
    
    // 控制整个物品栏位置的变量
    private int inventoryX = 8;  // 物品栏X坐标
    private int inventoryY = 84; // 物品栏Y坐标
    
    public TravelServiceTerminalScreen(TravelServiceTerminalMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176; // 大箱子宽度
        this.imageHeight = 222; // 大箱子高度 (168 + 54)
        this.inventoryLabelY = this.imageHeight - 94; // 物品栏标签位置
    }

    @Override
    protected void init() {
        super.init();
        
        // 设置菜单的物品栏位置
        if (this.menu instanceof TravelServiceTerminalMenu) {
            // 位置设置现在在构造函数中完成，这里不需要额外设置
        }
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, TEXTURE);
        int x = (this.width - this.imageWidth) / 2;
        int y = (this.height - this.imageHeight) / 2;
        
        // 渲染大箱子背景
        guiGraphics.blit(TEXTURE, x, y, 0, 0, this.imageWidth, this.imageHeight);
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        // 渲染标题
        guiGraphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x404040, false);
        
        // 渲染物品栏标签，使用自定义位置
        guiGraphics.drawString(this.font, this.playerInventoryTitle, 
             8, this.inventoryLabelY , 0x404040, false);
    }

    // 设置物品栏位置的方法
    public void setInventoryPosition(int x, int y) {
        this.inventoryX = x;
        this.inventoryY = y;
    }

    // 获取物品栏位置的方法
    public int getInventoryX() {
        return inventoryX;
    }

    public int getInventoryY() {
        return inventoryY;
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(guiGraphics);
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        this.renderTooltip(guiGraphics, mouseX, mouseY);
        
        // 调试：显示槽位位置信息
        renderDebugInfo(guiGraphics);
    }
    
    private void renderDebugInfo(GuiGraphics guiGraphics) {
        int x = (this.width - this.imageWidth) / 2;
        int y = (this.height - this.imageHeight) / 2;
        
        // 显示输入槽位置 (80, 20)
        guiGraphics.drawString(this.font, "输入槽: (" + (x + 80) + ", " + (y + 20) + ")", 10, 10, 0xFFFFFF, false);
        
        // 显示输出槽位置 (80, 50)  
        guiGraphics.drawString(this.font, "输出槽: (" + (x + 80) + ", " + (y + 50) + ")", 10, 20, 0xFFFFFF, false);
        
        // 显示屏幕中心位置
        guiGraphics.drawString(this.font, "屏幕中心: (" + x + ", " + y + ")", 10, 30, 0xFFFFFF, false);
        
        // 显示槽位总数
        guiGraphics.drawString(this.font, "槽位总数: " + this.menu.slots.size(), 10, 40, 0xFFFFFF, false);
    }
}