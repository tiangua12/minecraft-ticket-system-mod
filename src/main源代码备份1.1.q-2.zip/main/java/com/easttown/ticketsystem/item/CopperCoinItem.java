// CopperCoinItem.java
package com.easttown.ticketsystem.item;

import net.minecraft.world.item.Item;

public class CopperCoinItem extends Item {
    public CopperCoinItem() {
        super(new Properties().stacksTo(64));
    }
}

