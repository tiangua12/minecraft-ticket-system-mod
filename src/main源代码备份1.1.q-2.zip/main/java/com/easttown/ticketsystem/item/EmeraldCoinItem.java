package com.easttown.ticketsystem.item;

import net.minecraft.world.item.Item;

public class EmeraldCoinItem extends Item {
    public EmeraldCoinItem() {
        super(new Properties().stacksTo(64));
    }
}