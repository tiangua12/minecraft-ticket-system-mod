// NetheriteCoinItem.java
package com.easttown.ticketsystem.item;

import net.minecraft.world.item.Item;

public class NetheriteCoinItem extends Item {
    public NetheriteCoinItem() {
        super(new Properties().stacksTo(64));
    }
}