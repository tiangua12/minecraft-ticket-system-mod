package com.easttown.ticketsystem.client;

import com.easttown.ticketsystem.TicketSystemMod;
import com.easttown.ticketsystem.screen.GateConfigScreen;
import com.easttown.ticketsystem.screen.TicketMachineScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import com.easttown.ticketsystem.init.MenuInit;

@Mod.EventBusSubscriber(modid = "ticketsystem", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            // 1. 售票机屏幕注册
            MenuScreens.register(MenuInit.TICKET_MACHINE_MENU.get(), TicketMachineScreen::new);
            
            // 2. 闸机配置屏幕注册
            MenuScreens.register(MenuInit.GATE_CONFIG_MENU.get(), GateConfigScreen::new);
            
            // 3. 注册坐标调试器
            MinecraftForge.EVENT_BUS.register(new CoordinateDebugger());
        });
    }
    
    // // 注册实体渲染器
    // @SubscribeEvent
    // public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // event.registerEntityRenderer(EntityTypeInit.GATE_DETECTOR.get(), GateDetectorRenderer::new);
    // }
}
