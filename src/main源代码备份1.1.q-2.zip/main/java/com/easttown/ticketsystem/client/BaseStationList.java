package com.easttown.ticketsystem.client;

import com.easttown.ticketsystem.screen.TicketMachineScreen;
import com.easttown.ticketsystem.util.LanguageHelper;
import com.easttown.ticketsystem.manager.StationManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSelectionList;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.network.chat.Component;

import java.util.*;

public abstract class BaseStationList 
    extends AbstractSelectionList<BaseStationList.StationEntry> {
    
    protected int hoveredIndex = -1;
    
    // 颜色常量
    protected static final int BACKGROUND = 0xFFE0F7FA;
    protected static final int NORMAL_BG = 0xFFB3E5FC;
    protected static final int SELECTED_BG = 0xFF03A9F4;
    protected static int HOVER_BG = 0xFF81D4FA;
    protected static final int START_BG = 0xFFB2EBF2;
    protected static final int NORMAL_TEXT = 0xFF01579B;
    protected static final int SELECTED_TEXT = 0xFFFFFFFF;
    protected static final int DISABLED_TEXT = 0xFF80DEEA;
    protected static final int START_TEXT = 0xFF81D4FA;
    
    protected final TicketMachineScreen screen;
    protected final List<String> stations = new ArrayList<>();
    protected int listX, listY, listWidth, listHeight;
    
    // 分页状态
    protected int currentPage = 0;
    protected int itemsPerPage;
    protected int totalPages = 1;
    
    protected boolean visible = true;
    
    // 滚动文本状态
    protected Map<String, Integer> scrollOffsets = new HashMap<>();
    protected Map<String, Long> scrollTimers = new HashMap<>();
    
    public BaseStationList(TicketMachineScreen screen, 
                         int x, int y, int width, int height) {
        super(
            Minecraft.getInstance(), 
            width,
            height,
            y,
            y + height,
            20
        );
        this.screen = screen;
        this.listX = x;
        this.listY = y;
        this.listWidth = width;
        this.listHeight = height;
        this.setLeftPos(x);
        
        // 计算每页显示的项目数量
        this.itemsPerPage = Math.max(1, height / this.itemHeight);
    }
    
    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    
    public void setPosition(int x, int y, int width, int height) {
        this.listX = x;
        this.listY = y;
        this.listWidth = width;
        this.listHeight = height;
        this.setLeftPos(x);
        this.y0 = y;
        this.y1 = y + height;
        this.width = width;
        this.height = height;
        
        // 重新计算每页显示的项目数量
        this.itemsPerPage = Math.max(1, height / this.itemHeight);
        updateTotalPages();
    }
    
    public void refreshStations(String filter) {
        this.clearEntries();
        Set<String> allStations = StationManager.getStations();
        stations.clear();
        
        for (String station : allStations) {
            if (filter.isEmpty() || station.toLowerCase().contains(filter.toLowerCase())) {
                stations.add(station);
                // 初始化滚动状态
                if (!scrollOffsets.containsKey(station)) {
                    scrollOffsets.put(station, 0);
                    scrollTimers.put(station, System.currentTimeMillis());
                }
            }
        }
        Collections.sort(stations);
        
        // 更新总页数
        updateTotalPages();
        
        // 确保当前页在有效范围内
        currentPage = Math.max(0, Math.min(currentPage, totalPages - 1));
        
        // 添加当前页的条目
        int startIndex = currentPage * itemsPerPage;
        int endIndex = Math.min(startIndex + itemsPerPage, stations.size());
        
        for (int i = startIndex; i < endIndex; i++) {
            String station = stations.get(i);
            this.addEntry(createEntry(station));
        }
    }
    
    private void updateTotalPages() {
        totalPages = stations.isEmpty() ? 1 : (int) Math.ceil((double) stations.size() / itemsPerPage);
    }
    
    protected abstract StationEntry createEntry(String station);
    
    protected abstract boolean canSelectStation(String station);
    
    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        if (!visible) return;
        
        updateHoverState(mouseX, mouseY);
        
        guiGraphics.fill(
            this.x0, this.y0, 
            this.x1, this.y1, 
            BACKGROUND
        );
        
        guiGraphics.renderOutline(
            this.x0, this.y0, 
            this.getWidth(), this.getHeight(), 
            0xFF03A9F4
        );
        
        // 绘制当前页的条目
        int startIndex = currentPage * itemsPerPage;
        int endIndex = Math.min(startIndex + itemsPerPage, stations.size());
        
        for (int i = startIndex; i < endIndex; i++) {
            int displayIndex = i - startIndex;
            StationEntry entry = this.getEntry(displayIndex);
            int yPos = this.y0 + (displayIndex * getItemHeight());
            
            if (yPos >= this.y0 && yPos + getItemHeight() <= this.y1) {
                boolean isHovered = (i == hoveredIndex);
                entry.render(
                    guiGraphics, 
                    i, 
                    yPos, 
                    this.x0, 
                    this.getWidth(),
                    getItemHeight(), 
                    mouseX, 
                    mouseY, 
                    isHovered, 
                    partialTicks
                );
            }
        }
    }
    
    private void updateHoverState(int mouseX, int mouseY) {
        hoveredIndex = -1;
        
        if (mouseX >= this.x0 && mouseX <= this.x1 && 
            mouseY >= this.y0 && mouseY <= this.y1) {
            
            int relativeY = mouseY - this.y0;
            int index = relativeY / getItemHeight();
            int actualIndex = currentPage * itemsPerPage + index;
            
            if (index >= 0 && index < itemsPerPage && actualIndex < stations.size()) {
                hoveredIndex = actualIndex;
            }
        }
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!visible) return false;
        
        // 处理车站选择
        if (button == 0 && mouseX >= this.x0 && mouseX <= this.x1 && 
            mouseY >= this.y0 && mouseY <= this.y1) {
            
            int relativeY = (int) (mouseY - this.y0);
            int index = relativeY / getItemHeight();
            int actualIndex = currentPage * itemsPerPage + index;
            
            if (actualIndex >= 0 && actualIndex < stations.size()) {
                String station = stations.get(actualIndex);
                if (canSelectStation(station)) {
                    screen.setSelectedStation(station);
                    return true;
                }
            }
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    // 翻页方法
    public void nextPage() {
        if (currentPage < totalPages - 1) {
            currentPage++;
            refreshStations(screen.getSearchText());
        }
    }
    
    public void prevPage() {
        if (currentPage > 0) {
            currentPage--;
            refreshStations(screen.getSearchText());
        }
    }
    
    public boolean hasNextPage() {
        return currentPage < totalPages - 1;
    }
    
    public boolean hasPrevPage() {
        return currentPage > 0;
    }
    
    @Override
    public void updateNarration(NarrationElementOutput output) {
        output.add(NarratedElementType.TITLE, Component.translatable("ticketsystem.narrator.station_list"));
        
        for (int i = 0; i < this.getItemCount(); i++) {
            StationEntry entry = this.getEntry(i);
            entry.updateNarration(output);
        }
    }
    
    public int getCurrentPage() {
        return currentPage;
    }
    
    public int getTotalPages() {
        return totalPages;
    }
    
    public int getHoveredIndex() {
        return hoveredIndex;
    }
    
    public List<String> getStations() {
        return stations;
    }
    
    public int getItemHeight() {
        return this.itemHeight;
    }
    
    protected void renderScrollingText(GuiGraphics guiGraphics, String text, 
                                      int left, int top, int width, int height, 
                                      int color, String stationKey) {
        int maxWidth = width - 10;
        int textWidth = Minecraft.getInstance().font.width(text);
        
        if (textWidth <= maxWidth) {
            guiGraphics.drawString(
                Minecraft.getInstance().font, 
                text, 
                left + 5, 
                top + (height - 8) / 2, 
                color, 
                false
            );
            return;
        }
        
        // 更新滚动偏移量
        long currentTime = System.currentTimeMillis();
        long lastUpdate = scrollTimers.getOrDefault(stationKey, currentTime);
        int scrollOffset = scrollOffsets.getOrDefault(stationKey, 0);
        
        if (currentTime - lastUpdate > 30) { // 每30ms更新一次
            scrollOffset = (scrollOffset + 1) % (textWidth + 40); // 40像素的暂停
            scrollOffsets.put(stationKey, scrollOffset);
            scrollTimers.put(stationKey, currentTime);
        }
        
        guiGraphics.enableScissor(left + 5, top, left + width - 5, top + height);
        
        int textX = left + 5 - scrollOffset;
        guiGraphics.drawString(
            Minecraft.getInstance().font, 
            text, 
            textX, 
            top + (height - 8) / 2, 
            color, 
            false
        );
        
        // 绘制重复文本以实现无缝滚动
        if (scrollOffset > textWidth - maxWidth) {
            int repeatX = textX + textWidth + 20; // 20像素的间隔
            guiGraphics.drawString(
                Minecraft.getInstance().font, 
                text, 
                repeatX, 
                top + (height - 8) / 2, 
                color, 
                false
            );
        }
        
        guiGraphics.disableScissor();
    }

    public abstract static class StationEntry extends AbstractSelectionList.Entry<StationEntry> {
        protected final String station;

        public StationEntry(String station) {
            this.station = station;
        }
        
        public abstract void render(GuiGraphics guiGraphics, int index, int top, int left, 
                                  int width, int height, int mouseX, int mouseY, 
                                  boolean isHovered, float partialTicks);
        
        public void updateNarration(NarrationElementOutput output) {
            output.add(NarratedElementType.TITLE, 
                Component.translatable("ticketsystem.narrator.station_entry", station));
        }
        
        public String getStation() {
            return station;
        }
    }
}