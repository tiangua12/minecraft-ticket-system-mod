
// IronCoinItem.java
package com.easttown.ticketsystem.item;

import net.minecraft.world.item.Item;

public class IronCoinItem extends Item {
    public IronCoinItem() {
        super(new Properties().stacksTo(64));
    }
}

