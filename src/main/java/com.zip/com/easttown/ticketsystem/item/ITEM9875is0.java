// NetheriteCoinItem.java
package com.easttown.ticketsystem.item;

import net.minecraft.world.item.Item;

public class ITEM9875is0 extends Item {
    public ITEM9875is0() {
        super(new Properties().stacksTo(64));
    }
}